来源https://t.me/Aa28413761
#投稿 @Kuraki 

# 埋堆堆
^https?:\/\/mob\.mddcloud\.com\.cn\/adApi\/advert\/(first|third)part\/advertList url reject-dict
^https?:\/\/t-dsp\.pinduoduo\.com url reject-200
^https?:\/\/mobads-pre-config\.cdn\.bcebos\.com\/preload\.php url reject-200
^http?:\/\/sfo\.mddcloud\.com\.cn\/api\/v2\/sfo\/popup_displays? url reject-dict
^https?:\/\/tower\.ubixioe\.com\/mob\/mediation url reject
^https?:\/\/toblog\.ctobsnssdk\.com url reject-200
^https?:\/\/conf-darwin\.xycdn\.com url reject-dict
^https?:\/\/sdk1xyajs\.data\.kuiniuca\.com url reject

hostname = sfo.mddcloud.com.cn, mob.mddcloud.com.cn, toblog.ctobsnssdk.com, t-dsp.pinduoduo.com, mobads-pre-config.cdn.bcebos.com, sdk1xyajs.data.kuiniuca.com,conf-darwin.xycdn.com,*.ubixioe.com
