 [如有侵权请联系我](https://t.me/lovebabyforever)

[![访问量](https://komarev.com/ghpvc/?username=Yu9191)](https://github.com/Yu9191)
[![GitHub 关注者](https://img.shields.io/github/followers/Yu9191?style=social)](https://github.com/Yu9191)

欢迎来到我的 GitHub 仓库！在这里，您可以找到我的最新项目和贡献。

| 统计项   | 数量                                                                 |
| -------- | -------------------------------------------------------------------- |
| 总访问量 | [![总访问量](https://komarev.com/ghpvc/?username=Yu9191)](https://github.com/Yu9191) |
| 访客     | [![访客](https://visitor-badge.glitch.me/badge?page_id=Yu9191.Yu9191)](https://github.com/Yu9191) |
| 关注者   | [![GitHub 关注者](https://img.shields.io/github/followers/Yu9191?style=social)](https://github.com/Yu9191) |

请随意探索并为我的项目做出贡献。如果您觉得它们有用，请不要忘记给它们一个星标！

- [GitHub 仓库](https://github.com/Yu9191)
- 累计访客量: ![累计访客量](https://profile-counter.glitch.me/Yu9191/count.svg)
- [星标数量](https://img.shields.io/github/stars/Yu9191/Rewrite?style=social): ![星标数量](https://img.shields.io/github/stars/Yu9191/Rewrite?style=social)

## My Gtihub Trohpy

<div align="center">

![](https://github-profile-trophy.vercel.app/?username=Sliverkiss)

</div>
 
## 仓库脚本合集 没加iTunes和api.reven的 请用叮当猫的

脚本链接：[点击查看脚本](https://raw.githubusercontent.com/Yu9191/Rewrite/main/BabyScript.txt)

最后更新时间：2024.3.28

## iTunes 合集

总共有 17 个软件在这个合集中。

脚本链接：[点击查看脚本](https://raw.githubusercontent.com/Yu9191/Rewrite/main/iTunes.js)

最后更新时间：2023.10.19

## Revenuecat 合集

总共有 11 个软件在这个合集中。

脚本链接：[点击查看脚本](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Revenuecat.js)

最后更新时间：2023.10.5最新

**请注意：** 这两个合集只包含iTunes和Revenuecat域名的软件。脚本仅供学习，请勿传播或售卖。如果您需要其他域名的软件，请查看仓库中的其他合集。

后续的iTunes软件，移步到 [这个链接](https://github.com/Yu9191/Rewrite/tree/main/itunes)。

# 应用 Rewrite 配置

| 网站/应用 | 标签 | 主机名 | Rewrite 脚本 |
|-----------|------|--------|--------------|
| Vista看天下 | 新闻阅读 | open3.vistastory.com | [Vista.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Vista.js), [vistamy.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/vistamy.js), [vistavip.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/vistavip.js) |
| 万兴喵影 | 工具 | api.300624.com | [wanxingmiaoying.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/wanxingmiaoying.js) |
| 网易有道词典 | 学习 | dict.youdao.com, business.youdao.com, api-overmind.youdao.com, cdke.youdao.com | [wyydcd.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/wyydcd.js) |
| 西窗烛,诗词之美 | 工具 | lchttpapi.xczim.com, avoscloud.com | [Xcz.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Xcz.js) |
| 消防行 三个软件合集 | 学习 | www.xfx119.com | [Xiaofangxing.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Xiaofangxing.js) |
| 小叶子架子鼓 | 音乐 | oneplay-api.instadrum.com, oneplay-api.xiaoyezi.com | [Xiaoyejiazigu.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Xiaoyejiazigu.js) |
| 星题库 | 学习 | cm15-c110-3.play.bokecc.com, mb.xinghengedu.com | [Xingtiku.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Xingtiku.js), [Xingtikukecheng.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Xingtikukecheng.js) |
| 熊猫博士 | 学习 | lp-vid.xiongmaoboshi.com, lp-api.xiongmaoboshi.com | [xiongmaoboshibaike.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xiongmaoboshibaike.js), [m3u8/xiongmaoboshibaike.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/m3u8/xiongmaoboshibaike.js) |
| 小歪微商 | 工具 | xw.jietuguanjia.com | [xiaowaiweishang.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xiaowaiweishang.js) |
| 小熊录屏 | 工具 | donate-api.recorder.duapps.com | [xiaoxiongluping.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xiaoxiongluping.js) |
| 小熊油耗 | 工具 | www.xiaoxiongyouhao.com | [xiaoxiongyouhao.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xiaoxiongyouhao.js) |
| 欣师网校 | 学习 | app.xinxuejy.com | [xswx.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xswx.js) |
| 寻简 | 工具 | api.mindyushu.com | [xunjian.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/xunjian.js) |
| 药店学堂 | 学习 | api.yaodiandaxue.vip | [yaodianxuetang.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yaodianxuetang.js) |
| 易百查 | 工具 | api.ebaicha.com | [yibaicha.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yibaicha.js) |
| 一念便签 | 工具 | yinian.pro | [yinianbianqian.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yinianbianqian.js) |
| 音壳 | 音乐 | www.notetech.org | [yinke.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yinke.js), [yinkedengji.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yinkedengji.js) |
| 音基考级宝 | 音乐学习 | music.hjyywh.com | [yjkjb.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yjkjb.js) |
| 乐理手册 | 音乐 | music-knowledge-api.quthing.com | [ylsc.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/ylsc.js) |
| 有谱么 |  | yopu.co | [youpume.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/youpume.js) |
| SODA相机 | 工具 | yueh.app168.cc | [yueh.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/yueh.js) |
| 知音律 | 音乐 | auth.production.metronautapp.cn | [Zhiyinlv.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/Zhiyinlv.js) |
| 朝暮计划 |  | app.zomoplan.com | [zhaomujihua.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/zhaomujihua.js) |
| 昭昭医考 |  | api.yikao88.com | [zhaozhaoyikao.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/zhaozhaoyikao.js) |
| 状元共享课堂 |  | xzykt.longmenshuju.com | [zygxkt.js](https://raw.githubusercontent.com/Yu9191/Rewrite/main/zygxkt.js) |


