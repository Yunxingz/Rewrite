
/******************************
脚本作者：@ios151
免责声明：仅供学习 严谨倒卖 （别卖了 求你们了）


[rewrite_local]
^https:\/\/xunji\.gxzckj\.com\/after310\/ios url script-response-body https://raw.githubusercontent.com/Yu9191/Rewrite/main/xunji_no_update.js


[mitm]
hostname = xunji.gxzckj.com


/*


var { body } = $response; 
$done({ 
    body: JSON.stringify({ 
        "success": true, 
        "res": { 
            "version": 0, 
            "list": [ 
            ] 
        } 
    })
